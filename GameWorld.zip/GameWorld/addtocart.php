<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Checkout</title>
</head>
<body>
	<div>
		<?php 
			include("inc/header.php")
		?>
	</div>
	<div>
		<?php 
			include("inc/menu.php")
		?>
	</div>
	<div id="checkout">
		<div class="title">Checkout</div>
		<table id="checkout-table">
			<thead>
				<tr>
					<th>Image</th>
					<th>Name</th>
					<th>Description</th>
					<th>Price</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><img src="images/magicka.jpg" class="checkout-image"></td>
					<td>Magicka</td>
					<td class="checkout-description">
						Magicka is a satirical action-adventure game set in a rich fantasy world based on Norse mythology. The player assumes the role of a wizard from a sacred order tasked with stopping an evil sorcerer who has thrown the world into turmoil, his foul creations besieging the forces of good.
					</td>
					<td>&euro;9,99</td>
				</tr>
				<tr>
					<td><img src="images/totalwarrome.jpg" class="checkout-image"></td>
					<td>Total War: Rome II</td>
					<td class="checkout-description">
						Emperor Edition is the definitive edition of ROME II, featuring an improved politics system, overhauled building chains, rebalanced battles and improved visuals in both campaign and battle
					</td>
					<td>&euro;54,99</td>
				</tr>
				<tr>
					<td><img src="images/totalwarrome.jpg" class="checkout-image"></td>
					<td>Total War: Rome II</td>
					<td class="checkout-description">
						Emperor Edition is the definitive edition of ROME II, featuring an improved politics system, overhauled building chains, rebalanced battles and improved visuals in both campaign and battle
					</td>
					<td>&euro;54,99</td>
				</tr>
			</tbody>
		</table>
		<div class="price">Total Price: &euro;119,97</div>
		<input class="checkout-order" type="submit" value="order">
	</div>
	<div>
		<?php 
			include("inc/footer.php")
		?>
	</div>
</body>
</html>