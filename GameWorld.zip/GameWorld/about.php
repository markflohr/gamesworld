<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>about</title>
</head>
<body>
	<div>
		<?php 
			include("inc/header.php")
		?>
	</div>
	<div>
		<?php 
			include("inc/menu.php")
		?>
	</div>
	<div id="about">
		<div class="title">About us</div>
		<div class="about-text">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eu lacus bibendum, scelerisque leo vel, maximus leo. Nam nec interdum turpis, vitae faucibus ante. Sed mattis feugiat sem sed malesuada. Nam erat magna, convallis sed leo quis, mollis faucibus eros. Fusce malesuada augue dui, a cursus nisi efficitur eget. Mauris imperdiet lectus augue, euismod hendrerit lacus commodo quis. Phasellus finibus tellus aliquam dolor accumsan, iaculis tempus ipsum placerat. Sed et dui justo. Donec hendrerit ante ac enim dapibus venenatis. Sed commodo at erat sodales cursus. Sed in mollis erat. Phasellus auctor, quam ut maximus eleifend, lorem est facilisis massa, non sodales diam massa sed magna.
			Duis maximus egestas massa, non sollicitudin magna. Curabitur ut tortor mi. Mauris vel odio egestas, eleifend neque ac, convallis quam. Nam porttitor dui et mauris scelerisque, vitae dictum massa imperdiet. Phasellus erat magna, pulvinar sed felis id, consectetur commodo elit. Mauris sit amet purus tortor. Donec ultricies sit amet mi id pharetra. In malesuada interdum urna, quis vestibulum urna elementum ut.
			In hac habitasse platea dictumst. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque vel leo pharetra, tincidunt metus id, dignissim risus. Nam eget felis in mi hendrerit imperdiet. Vivamus lacinia ex a auctor fringilla. Curabitur eu iaculis risus. Donec id erat finibus, pulvinar odio ac, dapibus mi. Etiam varius bibendum pretium. Donec mauris dui, volutpat a ultrices nec, feugiat non ligula. Nam vitae tempor erat, eget lobortis ante. Fusce vulputate tortor massa, non porta mauris dignissim condimentum.
		</div>
	</div>
	<div>
		<?php 
			include("inc/footer.php")
		?>
	</div>
</body>
</html>