<link rel="stylesheet" type="text/css" href="css/style.css">
<div id="footer">
	<footer class="footer-text">Created by Mark Flohr</footer>
</div>