<link rel="stylesheet" type="text/css" href="css/style.css">
<div id="main-nav">
<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="games.php">Games</a></li>
	<li><a href="about.php">About us</a></li>
	<li><a href="contact.php">Contact</a></li>
</ul>
<a href="addtocart.php" class="checkout">Checkout</a>
</div>