<link rel="stylesheet" type="text/css" href="css/style.css">
<header id="header">
	<div id="logo">
		<a href="index.php">GameWorld</a>
	</div>
</header>