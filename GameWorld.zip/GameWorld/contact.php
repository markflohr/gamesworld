<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Contact</title>
</head>
<body>
	<div>
		<?php 
			include("inc/header.php")
		?>
	</div>
	<div>
		<?php 
			include("inc/menu.php")
		?>
	</div>
	<div id="contact">
		<div class="title">Contact us</div>
		<div class="contact-text">
		 <ul class="contact-input">
        <li>
            Email : <input type="text" name="two" class="email" value=""
            placeholder="Your Email">
        </li>
        <li>
            <label>Question : </label>
            <textarea type="text" name="two" class="question" placeholder="Your Question/Complain/"></textarea>
        </li>
        <input class="submit" type="submit" value="Send">
    </ul>	
		</div>
	</div>
	<div>
		<?php 
			include("inc/footer.php")
		?>
	</div>
</body>
</html>