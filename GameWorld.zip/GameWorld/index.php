<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>GameWorld</title>
</head>
<body>
	<div>
		<?php 
			include("inc/header.php")
		?>
	</div>
	<div>
		<?php
		include("inc/menu.php")
		?>
		<div id="banner">
			<div>
				<ul>
					<li class="banner-text1">Welcome to GameWorld</li>
					<li class="banner-text2">The most complete webshop!</li>
				</ul>
				<img src="images/banner.jpg" width="1410">
			</div>
		</div>
	</div>
	<div id="platform">
		<a href="games.php?game_categoryid=1"><div class="pc">PC</div></a>
		<a href="games.php?game_categoryid=2"><div class="playstation">Playstation</div></a>
		<a href="games.php?game_categoryid=3"><div class="xbox">Xbox</div></a>	
		<div class="clearfix"></div>
	</div>
	<div>
		<?php 
			include("inc/footer.php")
		?>
	</div>
</body>
</html>