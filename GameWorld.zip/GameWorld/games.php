<?php 
	$servername = "localhost";
	$username = "root";
	$password = "";
	$gameworld = "gameworld";
	$catid = 0;
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Games</title>
</head>
<body>
	<div>
		<?php 
			include("inc/header.php")
		?>
	</div>
	<div>
		<?php 
			include("inc/menu.php")
		?>
	</div>
	<div class="clearfix"></div>
	<div class="main">
		<?php
            $conn = new mysqli($servername, $username, $password, $gameworld);

            if ($conn->connect_error) 
            {
                die("Connection failed: " . $conn->connect_error);
            }

			if (isset($_GET["game_categoryid"])) 
			{
    			$catid = $_GET["game_categoryid"];
				$sql = "SELECT game_title, game_description, game_price, game_image, game_categoryid FROM games WHERE game_categoryid = $catid";
				$result = $conn->query($sql);
			}
			else
			{
				$sql = "SELECT game_title, game_description, game_price, game_image, game_categoryid FROM games";
				$result = $conn->query($sql);
			}

            if ($catid == 1) 
            {
                echo "<div class=title><h3>PC</h3></div>";
            }
            else if ($catid == 2) 
            {
                echo "<div class=title><h3>PlayStation</h3></div>";
            }
            else if ($catid == 3) 
            {
                echo "<div class=title><h3>Xbox</h3></div>";
            }
            else
            {
            	echo "<div class=title><h3>All games<h3></div>";
            }


            if ($result->num_rows > 0) 
            {
                while($row = $result->fetch_assoc()) {
       	?>
        <div class="main-card">
			<img src="images/<?php echo $row["game_image"]; ?>">
            <div class="price-games">&euro;<?php echo $row["game_price"];?></div>
            <div class="name"><?php echo $row["game_title"]; ?></div>
            <div class="order">ORDER NOW</div>
        </div>
        <?php
           	}
        ?>
        <div class="clearfix"></div>
        <?php
            } 
            else 
            {
                echo "0 results";
       	    }
            $conn->close();
        ?>
	</div>
	<div>
		<?php 
			include("inc/footer.php")
 		?>
	</div>
</body>
</html>